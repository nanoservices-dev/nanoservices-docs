// nanoServices core (rev5.4) — Task
// Generated 2025-08-15T09:12:22.828289

package dev.nanoservices;
import java.util.ArrayList;

import java.util.List;

public abstract class Task extends Plan {
    private final List<Message> messages = new ArrayList<>();

    protected Task() { super(); }

    protected Task(Message message) {
        super();
        this.message = message;
    }

    
    

    //convenience
    public NanoService nanoService() { return (message != null) ? message.nanoService() : null; }

    // list-style accessors (Idea-side rework)
    public List<Message> messages() { return this.messages; }

    public void setMessages(List<Message> messages) {
        this.messages.clear();
        if (messages != null) this.messages.addAll(messages);
    }

    public void addMessage(Message message) {
        this.messages.add(message);
    }

    public void removeMessage(Message message) {
        this.messages.remove(message);
    }

}