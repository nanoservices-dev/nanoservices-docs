// nanoServices core (rev5.4) — View
// Generated 2025-08-15T09:12:22.828289

package dev.nanoservices;
import java.util.List;
import java.util.ArrayList;

public abstract class View extends Transformation {

    private String language;
    private String location;
    private String checksum;

    private final List<Perspective> perspectives = new ArrayList<>();

    protected View() { super(); }
    protected View(String language, String location, String checksum) {
        super();
        this.language = language;
        this.location = location;
        this.checksum = checksum;
    }
    protected View(String language, String location, String checksum, Perspective perspective) {
        this(language, location, checksum);
        this.perspective = perspective;
    }

    public String language() { return language; }
    public void setLanguage(String language) { this.language = language; }

    public String location() { return location; }
    public void setLocation(String location) { this.location = location; }

    public String checksum() { return checksum; }
    public void setChecksum(String checksum) { this.checksum = checksum; }

    
    

    // list-style accessors (Idea-side rework)
    public List<Perspective> perspectives() { return this.perspectives; }

    public void setPerspectives(List<Perspective> perspectives) {
        this.perspectives.clear();
        if (perspectives != null) this.perspectives.addAll(perspectives);
    }

    public void addPerspective(Perspective perspective) {
        this.perspectives.add(perspective);
    }

    public void removePerspective(Perspective perspective) {
        this.perspectives.remove(perspective);
    }

}