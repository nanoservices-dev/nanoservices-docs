// nanoServices core (rev5.4) — Plan
// Generated 2025-08-15T09:12:22.828289

package dev.nanoservices;
import java.util.ArrayList;

import java.util.List;

public abstract class Plan extends Contract {

    private final List<Schedule> schedules = new ArrayList<>();

    protected Plan() { super(); }

    protected Plan(Schedule schedule) {
        super();
        this.schedule = schedule;
    }

    
    

    //convenience
    public Service service() { return (schedule != null) ? schedule.service() : null; }

    // list-style accessors (Idea-side rework)
    public List<Schedule> schedules() { return this.schedules; }

    public void setSchedules(List<Schedule> schedules) {
        this.schedules.clear();
        if (schedules != null) this.schedules.addAll(schedules);
    }

    public void addSchedule(Schedule schedule) {
        this.schedules.add(schedule);
    }

    public void removeSchedule(Schedule schedule) {
        this.schedules.remove(schedule);
    }

}