// nanoServices core (rev5.4) — Contract
// Generated 2025-08-15T09:12:22.828289

package dev.nanoservices;

import java.util.ArrayList;
import java.util.List;

public abstract class Contract extends View {

    private final List<Persona> parties = new ArrayList<>();

    private final List<Policy> policies = new ArrayList<>();

    protected Contract() { super(); }
    protected Contract(List<Persona> parties){
        super();
        if (parties != null) this.parties.addAll(parties);
    }

    protected Contract(List<Persona> parties, Policy policy) { this(parties); this.policy = policy; }

    public List<Persona> parties() { return parties; }
    public void setParties(List<Persona> parties) {
        //TODO: check clear?
        this.parties.clear();
        if (parties != null)
            this.parties.addAll(parties);
    }
    public void addParty(Persona persona){
        if (persona != null) this.parties.add(persona);
    }

    
    

    //convenience
    public System system() { return (policy != null) ? policy.system() : null; }

    // list-style accessors (Idea-side rework)
    public List<Policy> policies() { return this.policies; }

    public void setPolicys(List<Policy> policies) {
        this.policies.clear();
        if (policies != null) this.policies.addAll(policies);
    }

    public void addPolicy(Policy policy) {
        this.policies.add(policy);
    }

    public void removePolicy(Policy policy) {
        this.policies.remove(policy);
    }

}