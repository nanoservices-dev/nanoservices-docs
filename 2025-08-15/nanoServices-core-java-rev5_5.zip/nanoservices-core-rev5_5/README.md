# nanoServices core — Java abstract model (rev5.5)
Generated: 2025-08-15T09:59:14.777916

- Service no longer contains Schedule.
- Service derives Plan via inherited Policy:
  - getPlan(): returns Policy.getContract() if it is a Plan.
  - setPlan(Plan): sets Policy.mirrored Contract to the Plan, and back-links the Policy on the Plan.