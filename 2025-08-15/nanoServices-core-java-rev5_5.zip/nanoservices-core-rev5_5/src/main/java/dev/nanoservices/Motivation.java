// nanoServices core (rev5.4) — Motivation
// Generated 2025-08-15T09:59:14.751468


package dev.nanoservices;
import java.util.*;
public abstract class Motivation extends Task {
    private Instruction instruction;
    protected Motivation(){ super(); }
    protected Motivation(List<Persona> parties){ super(parties); }
    protected Motivation(List<Persona> parties, Policy policy, Schedule schedule, Message message, Instruction instruction){ super(parties, policy, schedule, message); this.instruction=instruction; }
    public Instruction getInstruction(){ return instruction; } public void setInstruction(Instruction i){ this.instruction=i; }
    public Process getProcess(){ return (instruction!=null) ? instruction.getProcess() : null; }
    public void setProcess(Process p){ if(instruction!=null) instruction.setProcess(p); }
}
