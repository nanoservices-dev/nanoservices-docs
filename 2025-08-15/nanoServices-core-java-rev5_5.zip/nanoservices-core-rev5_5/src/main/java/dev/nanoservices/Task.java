// nanoServices core (rev5.4) — Task
// Generated 2025-08-15T09:59:14.751468


package dev.nanoservices;
import java.util.*;
public abstract class Task extends Plan {
    private Message message;
    protected Task(){ super(); }
    protected Task(List<Persona> parties){ super(parties); }
    protected Task(List<Persona> parties, Policy policy, Schedule schedule, Message message){ super(parties, policy, schedule); this.message=message; }
    public Message getMessage(){ return message; } public void setMessage(Message m){ this.message=m; }
    public NanoService getNanoService(){ return (message!=null) ? message.getNanoService() : null; }
    public void setNanoService(NanoService s){ if(message!=null) message.setNanoService(s); }
}
