// nanoServices core (rev5.4) — Instruction
// Generated 2025-08-15T09:59:14.751468


package dev.nanoservices;
public abstract class Instruction extends Message {
    private Process process; private Motivation motivation;
    protected Instruction(){ super(); }
    protected Instruction(Process p, Motivation m){ this.process=p; this.motivation=m; }
    public Process getProcess(){ return process; } public void setProcess(Process p){ this.process=p; }
    public Motivation getMotivation(){ return motivation; } public void setMotivation(Motivation m){ this.motivation=m; }
}
