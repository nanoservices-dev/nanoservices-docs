// nanoServices core (rev5.4) — Idea
// Generated 2025-08-15T09:59:14.751468


package dev.nanoservices;
public abstract class Idea extends Entity {
    private String type; private Double priority;
    protected Idea(){ super(); }
    protected Idea(String type, Double priority){ this.type=type; this.priority=priority; }
    protected Idea(String type, Double priority, Entity e){ super(e); this.type=type; this.priority=priority; }
    public String type(){ return type; } public void setType(String t){ this.type=t; }
    public Double priority(){ return priority; } public void setPriority(Double p){ this.priority=p; }
}
