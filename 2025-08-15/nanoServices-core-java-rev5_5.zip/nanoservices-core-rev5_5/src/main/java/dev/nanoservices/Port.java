// nanoServices core (rev5.4) — Port
// Generated 2025-08-15T09:59:14.751468


package dev.nanoservices;
public abstract class Port extends Manifestation {
    private String uid; private Projection projection; private Perspective opens; private View allows;
    protected Port(){ super(); }
    protected Port(String uid, Projection projection){ this.uid=uid; this.projection=projection; }
    protected Port(String uid, Projection projection, Perspective opens, View allows){ this(uid, projection); this.opens=opens; this.allows=allows; }
    public String uid(){ return uid; } public void setUid(String id){ this.uid=id; }
    public Projection projection(){ return projection; } public void setProjection(Projection p){ this.projection=p; }
    public Perspective opens(){ return opens; } public void setOpens(Perspective o){ this.opens=o; }
    public View allows(){ return allows; } public void setAllows(View a){ this.allows=a; }
    public void open(){ /* no-op */ }
}
