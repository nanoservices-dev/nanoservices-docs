// nanoServices core (rev5.4) — Perspective
// Generated 2025-08-15T09:59:14.751468


package dev.nanoservices;
public abstract class Perspective extends Projection {
    private Projection projection;
    protected Perspective(){ super(); }
    protected Perspective(Projection projection){ this.projection=projection; }
    public Projection projection(){ return projection; } public void setProjection(Projection p){ this.projection=p; }
    public void secure(){ /* no-op */ }
}
