// nanoServices core (rev5.4) — Schedule
// Generated 2025-08-15T09:59:14.751468


package dev.nanoservices;
public abstract class Schedule extends Policy {
    private Service service; private Plan plan;
    protected Schedule(){ super(); }
    protected Schedule(Service service, Plan plan){ this.service=service; this.plan=plan; }
    public Service getService(){ return service; } public void setService(Service s){ this.service=s; }
    public Plan getPlan(){ return plan; } public void setPlan(Plan p){ this.plan=p; }
}
