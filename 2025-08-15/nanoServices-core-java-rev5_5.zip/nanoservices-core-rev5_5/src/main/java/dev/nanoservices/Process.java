// nanoServices core (rev5.4) — Process
// Generated 2025-08-15T09:59:14.751468


package dev.nanoservices;
public abstract class Process extends NanoService {
    private String pid; private Instruction instruction;
    protected Process(){ super(); }
    protected Process(String pid){ this.pid=pid; }
    protected Process(String pid, Instruction instruction){ this.pid=pid; this.instruction=instruction; }
    public String getPid(){ return pid; } public void setPid(String p){ this.pid=p; }
    public Instruction getInstruction(){ return instruction; } public void setInstruction(Instruction i){ this.instruction=i; }
    public Motivation getMotivation(){ return (instruction!=null) ? instruction.getMotivation() : null; }
    public void setMotivation(Motivation m){ if(instruction!=null){ instruction.setMotivation(m); if(m!=null) m.setInstruction(instruction); } }
}
