// nanoServices core (rev5.4) — Persona
// Generated 2025-08-15T09:59:14.751468


package dev.nanoservices;
public abstract class Persona extends Entity {
    private String resource; private Idea idea; private World world;
    protected Persona(){ super(); }
    protected Persona(String resource){ this.resource=resource; }
    protected Persona(String resource, Idea idea, World world){ this.resource=resource; this.idea=idea; this.world=world; }
    protected Persona(String resource, Entity e, Idea idea, World world){ super(e); this.resource=resource; this.idea=idea; this.world=world; }
    public String resource(){ return resource; } public void setResource(String r){ this.resource=r; }
    public Idea idea(){ return idea; } public void setIdea(Idea i){ this.idea=i; }
    public World world(){ return world; } public void setWorld(World w){ this.world=w; }
}
