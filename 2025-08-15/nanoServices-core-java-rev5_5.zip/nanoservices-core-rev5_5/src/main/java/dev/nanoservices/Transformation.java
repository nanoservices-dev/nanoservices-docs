// nanoServices core (rev5.4) — Transformation
// Generated 2025-08-15T09:59:14.751468


package dev.nanoservices;
public abstract class Transformation extends Idea {
    private String purpose; private Double entropy;
    protected Transformation(){ super(); }
    protected Transformation(String purpose, Double entropy){ this.purpose=purpose; this.entropy=entropy; }
    protected Transformation(String purpose, Double entropy, Entity copyFrom){ super(copyFrom); this.purpose=purpose; this.entropy=entropy; }
    public String purpose(){ return purpose; } public void setPurpose(String p){ this.purpose=p; }
    public Double entropy(){ return entropy; } public void setEntropy(Double e){ this.entropy=e; }
}
