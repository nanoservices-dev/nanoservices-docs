// nanoServices core (rev5.4) — View
// Generated 2025-08-15T09:59:14.751468


package dev.nanoservices;
public abstract class View extends Transformation {
    private String language; private String location; private String checksum;
    private Perspective perspective; private Port requires;
    protected View(){ super(); }
    protected View(String language, String location, String checksum){ this.language=language; this.location=location; this.checksum=checksum; }
    protected View(String language, String location, String checksum, Perspective perspective, Port requires){ this(language, location, checksum); this.perspective=perspective; this.requires=requires; }
    public String language(){ return language; } public void setLanguage(String l){ this.language=l; }
    public String location(){ return location; } public void setLocation(String l){ this.location=l; }
    public String checksum(){ return checksum; } public void setChecksum(String c){ this.checksum=c; }
    public Perspective perspective(){ return perspective; } public void setPerspective(Perspective p){ this.perspective=p; }
    public Port requires(){ return requires; } public void setRequires(Port r){ this.requires=r; }
}
