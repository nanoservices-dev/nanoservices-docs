// nanoServices core (rev5.4) — System
// Generated 2025-08-15T09:59:14.751468


package dev.nanoservices;
import java.util.*;
public abstract class System extends Port {
    private final List<Manifestation> elements = new ArrayList<>();
    private Policy policy;
    protected System(){ super(); }
    protected System(List<Manifestation> elements){ if(elements!=null) this.elements.addAll(elements); }
    protected System(List<Manifestation> elements, Policy policy){ this(elements); this.policy=policy; }
    public List<Manifestation> getElements(){ return elements; }
    public void setElements(List<Manifestation> els){ this.elements.clear(); if(els!=null) this.elements.addAll(els); }
    public Policy getPolicy(){ return policy; } public void setPolicy(Policy p){ this.policy=p; }
    public Contract getContract(){ return (policy!=null) ? policy.getContract() : null; }
    public void setContract(Contract c){ if(policy!=null){ policy.setContract(c); if(c!=null){ c.setPolicy(policy); c.setSystem(this); } } }
}
