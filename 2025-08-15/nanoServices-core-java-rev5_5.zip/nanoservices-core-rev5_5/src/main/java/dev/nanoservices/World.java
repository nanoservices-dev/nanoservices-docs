// nanoServices core (rev5.4) — World
// Generated 2025-08-15T09:59:14.751468


package dev.nanoservices;
public abstract class World extends Entity {
    private String status;
    protected World(){ super(); }
    protected World(String status){ this.status=status; }
    protected World(String status, Entity e){ super(e); this.status=status; }
    public String status(){ return status; } public void setStatus(String s){ this.status=s; }
}
