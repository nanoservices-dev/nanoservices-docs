// nanoServices core (rev5.4) — Projection
// Generated 2025-08-15T09:59:14.751468


package dev.nanoservices;
public abstract class Projection extends Persona {
    private String contentType; private String scope;
    private Manifestation manifestation; private Transformation transformation;
    protected Projection(){ super(); }
    protected Projection(String contentType, String scope){ this.contentType=contentType; this.scope=scope; }
    protected Projection(String contentType, String scope, Manifestation manifestation, Transformation transformation){
        this(contentType, scope); this.manifestation=manifestation; this.transformation=transformation;
    }
    public String contentType(){ return contentType; } public void setContentType(String c){ this.contentType=c; }
    public String scope(){ return scope; } public void setScope(String s){ this.scope=s; }
    public Manifestation manifestation(){ return manifestation; } public void setManifestation(Manifestation m){ this.manifestation=m; }
    public Transformation transformation(){ return transformation; } public void setTransformation(Transformation t){ this.transformation=t; }
}
