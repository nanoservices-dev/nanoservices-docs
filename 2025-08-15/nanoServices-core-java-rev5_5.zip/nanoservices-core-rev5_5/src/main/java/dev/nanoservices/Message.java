// nanoServices core (rev5.4) — Message
// Generated 2025-08-15T09:59:14.751468


package dev.nanoservices;
public abstract class Message extends Schedule {
    private NanoService nanoService; private Task task;
    protected Message(){ super(); }
    protected Message(NanoService ns, Task t){ this.nanoService=ns; this.task=t; }
    public NanoService getNanoService(){ return nanoService; } public void setNanoService(NanoService s){ this.nanoService=s; }
    public Task getTask(){ return task; } public void setTask(Task t){ this.task=t; }
    public abstract Message process(Message input);
}
