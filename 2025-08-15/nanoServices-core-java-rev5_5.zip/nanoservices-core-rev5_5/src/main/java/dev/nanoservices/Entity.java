// nanoServices core (rev5.4) — Entity
// Generated 2025-08-15T09:59:14.751468


package dev.nanoservices;
public abstract class Entity {
    private String version;
    protected Entity() {}
    protected Entity(String version){ this.version = version; }
    protected Entity(Entity e){ if(e!=null) this.version = e.version(); }
    public String version(){ return version; }
    public void setVersion(String v){ this.version = v; }
}
