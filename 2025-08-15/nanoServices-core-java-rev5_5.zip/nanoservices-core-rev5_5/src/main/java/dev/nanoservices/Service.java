// nanoServices core (rev5.5) — Service
// Generated 2025-08-15T09:59:14.777916

package dev.nanoservices;
import java.util.*;
public abstract class Service extends System {
    protected Service() { super(); }
    protected Service(List<Manifestation> elements) { super(elements); }
    protected Service(List<Manifestation> elements, Policy policy) { super(elements, policy); }

    public Plan getPlan() {
        Policy p = getPolicy();
        if (p == null) return null;
        Contract c = p.getContract();
        return (c instanceof Plan) ? (Plan) c : null;
    }

    public void setPlan(Plan plan) {
        Policy p = getPolicy();
        if (p != null) {
            p.setContract(plan);
            if (plan != null) plan.setPolicy(p);
        }
    }
}
