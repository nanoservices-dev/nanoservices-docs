# nanoServices core — Java abstract model (rev5.1)
Generated: 2025-08-15T08:53:52.826325

Changes vs rev5:
- Manifestation: now only `time` and `persona` (no direct link to Idea side).
- Projection: now bridges World↔Idea via `Manifestation` and `Transformation` fields.
- All other classes remain as in rev5 (encapsulation + bean getters/setters).