// nanoServices core (rev5.1) — Perspective
// Generated 2025-08-15T08:53:52.826325

package dev.nanoservices;

public abstract class Perspective extends Projection {
    private Projection projection;

    protected Perspective() { super(); }
    protected Perspective(Projection projection) { this.projection = projection; }

    public Projection projection() { return projection; }
    public void setProjection(Projection projection) { this.projection = projection; }

    public void secure() { /* no-op */ }
}
