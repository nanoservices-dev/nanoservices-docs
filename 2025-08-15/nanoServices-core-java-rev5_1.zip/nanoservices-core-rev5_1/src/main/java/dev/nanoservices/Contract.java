// nanoServices core (rev5.1) — Contract
// Generated 2025-08-15T08:53:52.826325

package dev.nanoservices;

import java.util.ArrayList;
import java.util.List;

public abstract class Contract extends View {
    private final List<Persona> parties = new ArrayList<>();
    private Policy policy;

    protected Contract() { super(); }
    protected Contract(List<Persona> parties) { super(); if (parties != null) this.parties.addAll(parties); }
    protected Contract(List<Persona> parties, Policy policy) { this(parties); this.policy = policy; }

    public List<Persona> getParties() { return parties; }
    public void setParties(List<Persona> parties) { this.parties.clear(); if (parties != null) this.parties.addAll(parties); }

    public Policy getPolicy() { return policy; }
    public void setPolicy(Policy policy) { this.policy = policy; }

    public System getSystem() { return (policy != null) ? policy.getSystem() : null; }
    public void setSystem(System s) { if (policy != null) policy.setSystem(s); }
}
