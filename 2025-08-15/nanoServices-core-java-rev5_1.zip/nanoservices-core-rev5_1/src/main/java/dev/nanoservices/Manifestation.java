// nanoServices core (rev5.1) — Manifestation
// Generated 2025-08-15T08:53:52.826325

package dev.nanoservices;

import java.time.Instant;

public abstract class Manifestation extends World {
    private Instant time;
    private Persona persona;

    protected Manifestation() { super(); }
    protected Manifestation(Instant time) { super(); this.time = time; }
    protected Manifestation(Instant time, Persona persona) {
        super();
        this.time = time;
        this.persona = persona;
    }

    public Instant time() { return time; }
    public void setTime(Instant time) { this.time = time; }

    public Persona persona() { return persona; }
    public void setPersona(Persona persona) { this.persona = persona; }
}
