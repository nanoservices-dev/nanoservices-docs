// nanoServices core (rev5.1) — Projection
// Generated 2025-08-15T08:53:52.826325

package dev.nanoservices;

public abstract class Projection extends Persona {
    private String contentType;
    private String scope;

    private Manifestation manifestation;   // World anchor
    private Transformation transformation; // Idea anchor

    private Persona persona;

    protected Projection() { super(); }

    protected Projection(String contentType, String scope) {
        super();
        this.contentType = contentType;
        this.scope = scope;
    }

    protected Projection(String contentType, String scope,
                         Persona persona,
                         Manifestation manifestation,
                         Transformation transformation) {
        this(contentType, scope);
        this.persona = persona;
        this.manifestation = manifestation;
        this.transformation = transformation;
    }

    public String contentType() { return contentType; }
    public void setContentType(String contentType) { this.contentType = contentType; }

    public String scope() { return scope; }
    public void setScope(String scope) { this.scope = scope; }

    public Persona persona() { return persona; }
    public void setPersona(Persona persona) { this.persona = persona; }

    public Manifestation manifestation() { return manifestation; }
    public void setManifestation(Manifestation manifestation) { this.manifestation = manifestation; }

    public Transformation transformation() { return transformation; }
    public void setTransformation(Transformation transformation) { this.transformation = transformation; }
}
