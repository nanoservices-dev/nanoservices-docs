// nanoServices core (rev3) — Persona
// Generated 2025-08-15T06:08:36.564566

package dev.nanoservices;

public abstract class Persona extends Entity {
    private String resource;
    private Idea idea;
    private World world;

    protected Persona() { super(); }
    protected Persona(String resource, Idea idea, World world) { super(); this.resource = resource; this.idea = idea; this.world = world; }
    protected Persona(String xmlDefinition) { super(xmlDefinition); }

    public String resource() { return resource; }
    public void setResource(String resource) { this.resource = resource; }
    public Idea idea() { return idea; }
    public void setIdea(Idea idea) { this.idea = idea; }
    public World world() { return world; }
    public void setWorld(World world) { this.world = world; }
}
