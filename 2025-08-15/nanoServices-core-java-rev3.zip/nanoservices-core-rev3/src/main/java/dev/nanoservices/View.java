// nanoServices core (rev3) — View
// Generated 2025-08-15T06:08:36.564566

package dev.nanoservices;

public abstract class View extends Transformation {
    private String language;
    private String location;
    private String checksum;
    private Perspective perspective;
    private Port requires;

    protected View() { super(); }
    protected View(String language, String location, String checksum, Perspective perspective) { super(); this.language = language; this.location = location; this.checksum = checksum; this.perspective = perspective; }
    protected View(String xmlDefinition) { super(xmlDefinition); }

    public String language() { return language; }
    public void setLanguage(String language) { this.language = language; }
    public String location() { return location; }
    public void setLocation(String location) { this.location = location; }
    public String checksum() { return checksum; }
    public void setChecksum(String checksum) { this.checksum = checksum; }
    public Perspective perspective() { return perspective; }
    public void setPerspective(Perspective perspective) { this.perspective = perspective; }
    public Port requires() { return requires; }
    public void setRequires(Port requires) { this.requires = requires; }

    public abstract Port requiresVerb();
    public abstract Perspective concretizes();
}
