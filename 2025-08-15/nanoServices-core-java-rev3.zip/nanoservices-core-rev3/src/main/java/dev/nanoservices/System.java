// nanoServices core (rev3) — System
// Generated 2025-08-15T06:08:36.564566

package dev.nanoservices;

import java.util.ArrayList;
import java.util.List;

public abstract class System extends Port {
    private Policy policy;
    private Contract serves;
    private List<Manifestation> elements = new ArrayList<>();

    protected System() { super(); }
    protected System(List<Manifestation> elements) { super(); if (elements != null) this.elements = new ArrayList<>(elements); }
    protected System(String xmlDefinition) { super(xmlDefinition); }

    public Policy policy() { return policy; }
    public void setPolicy(Policy policy) { this.policy = policy; }
    public Contract servesField() { return serves; }
    public void setServesField(Contract serves) { this.serves = serves; }
    public List<Manifestation> elements() { return elements; }
    protected void setElements(List<Manifestation> elements) { this.elements = (elements != null) ? new ArrayList<>(elements) : new ArrayList<>(); }

    public abstract dev.nanoservices.Contract serves();
    public abstract dev.nanoservices.Policy respects();
}
