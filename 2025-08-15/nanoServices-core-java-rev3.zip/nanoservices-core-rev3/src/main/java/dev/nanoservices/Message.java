// nanoServices core (rev3) — Message
// Generated 2025-08-15T06:08:36.564566

package dev.nanoservices;

public abstract class Message extends Schedule {
    private Schedule schedule;
    protected Message() { super(); }
    protected Message(Schedule schedule) { super(); this.schedule = schedule; }
    protected Message(String xmlDefinition) { super(xmlDefinition); }
    public Schedule schedule() { return schedule; }
    public void setSchedule(Schedule schedule) { this.schedule = schedule; }
    public abstract Message process(Message input);
}
