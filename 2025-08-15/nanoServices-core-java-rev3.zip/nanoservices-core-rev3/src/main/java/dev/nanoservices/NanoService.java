// nanoServices core (rev3) — NanoService
// Generated 2025-08-15T06:08:36.564566

package dev.nanoservices;

public abstract class NanoService extends Service {
    private Message message;
    private Task executes;

    protected NanoService() { super(); }
    protected NanoService(java.util.List<Manifestation> elements) { super(elements); }
    protected NanoService(String xmlDefinition) { super(xmlDefinition); }

    public Message message() { return message; }
    public void setMessage(Message message) { this.message = message; }
    public Task executesField() { return executes; }
    public void setExecutesField(Task executes) { this.executes = executes; }

    public abstract Task executes();
    public abstract Message sends();
}
