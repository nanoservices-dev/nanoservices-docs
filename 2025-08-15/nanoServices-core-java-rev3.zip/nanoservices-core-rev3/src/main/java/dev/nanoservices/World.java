// nanoServices core (rev3) — World
// Generated 2025-08-15T06:08:36.564566

package dev.nanoservices;

public abstract class World extends Entity {
    private String status;

    protected World() { super(); }
    protected World(String version, String status) { super(version); this.status = status; }
    protected World(String xmlDefinition) { super(xmlDefinition); }
    protected World(String version, String xmlDefinition, String status) { super(version, xmlDefinition); this.status = status; }

    public String status() { return status; }
    public void setStatus(String status) { this.status = status; }
}
