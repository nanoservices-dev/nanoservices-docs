// nanoServices core (rev3) — Process
// Generated 2025-08-15T06:08:36.564566

package dev.nanoservices;

public abstract class Process extends NanoService {
    private String pid;
    private Instruction instruction;
    private Motivation targets;

    protected Process() { super(); }
    protected Process(String pid, Instruction instruction) { super(); this.pid = pid; this.instruction = instruction; }
    protected Process(String xmlDefinition) { super(xmlDefinition); }

    public String pid() { return pid; }
    public void setPid(String pid) { this.pid = pid; }
    public Instruction instruction() { return instruction; }
    public void setInstruction(Instruction instruction) { this.instruction = instruction; }
    public Motivation targetsField() { return targets; }
    public void setTargetsField(Motivation targets) { this.targets = targets; }

    public abstract Motivation targets();
    public abstract Instruction runs();
}
