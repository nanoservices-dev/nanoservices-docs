// nanoServices core (rev3) — Task
// Generated 2025-08-15T06:08:36.564566

package dev.nanoservices;

public abstract class Task extends Plan {
    private Message message;
    private NanoService defines;

    protected Task() { super(); }
    protected Task(java.util.List<Persona> parties) { super(parties); }
    protected Task(String xmlDefinition) { super(xmlDefinition); }

    public Message message() { return message; }
    public void setMessage(Message message) { this.message = message; }
    public NanoService defines() { return defines; }
    public void setDefines(NanoService defines) { this.defines = defines; }

    public abstract NanoService definesVerb();
    public abstract Message reports();
}
