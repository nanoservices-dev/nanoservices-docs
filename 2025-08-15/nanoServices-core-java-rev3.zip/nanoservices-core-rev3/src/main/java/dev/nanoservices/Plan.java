// nanoServices core (rev3) — Plan
// Generated 2025-08-15T06:08:36.564566

package dev.nanoservices;

public abstract class Plan extends Contract {
    private Schedule schedule;
    private Service describes;

    protected Plan() { super(); }
    protected Plan(java.util.List<Persona> parties) { super(parties); }
    protected Plan(String xmlDefinition) { super(xmlDefinition); }

    public Schedule schedule() { return schedule; }
    public void setSchedule(Schedule schedule) { this.schedule = schedule; }
    public Service describes() { return describes; }
    public void setDescribes(Service describes) { this.describes = describes; }

    public abstract Service describesVerb();
    public abstract Schedule schemes();
}
