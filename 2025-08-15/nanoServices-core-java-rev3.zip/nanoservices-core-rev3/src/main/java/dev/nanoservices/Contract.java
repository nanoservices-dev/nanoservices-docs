// nanoServices core (rev3) — Contract
// Generated 2025-08-15T06:08:36.564566

package dev.nanoservices;

import java.util.ArrayList;
import java.util.List;

public abstract class Contract extends View {
    private Policy policy;
    private List<Persona> parties = new ArrayList<>();

    protected Contract() { super(); }
    protected Contract(List<Persona> parties) { super(); if (parties != null) this.parties = new ArrayList<>(parties); }
    protected Contract(String xmlDefinition) { super(xmlDefinition); }

    public Policy policy() { return policy; }
    public void setPolicy(Policy policy) { this.policy = policy; }
    public List<Persona> parties() { return parties; }
    protected void setParties(List<Persona> parties) { this.parties = (parties != null) ? new ArrayList<>(parties) : new ArrayList<>(); }

    public abstract System restricts();
    public abstract Policy justifies();
}
