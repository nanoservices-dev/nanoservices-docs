// nanoServices core (rev3) — Instruction
// Generated 2025-08-15T06:08:36.564566

package dev.nanoservices;

public abstract class Instruction extends Message {
    private Message message;
    protected Instruction() { super(); }
    protected Instruction(Message message) { super(); this.message = message; }
    protected Instruction(String xmlDefinition) { super(xmlDefinition); }
    public Message message() { return message; }
    public void setMessage(Message message) { this.message = message; }
}
