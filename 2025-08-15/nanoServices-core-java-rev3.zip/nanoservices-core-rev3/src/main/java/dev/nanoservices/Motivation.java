// nanoServices core (rev3) — Motivation
// Generated 2025-08-15T06:08:36.564566

package dev.nanoservices;

public abstract class Motivation extends Task {
    private Instruction instruction;

    protected Motivation() { super(); }
    protected Motivation(java.util.List<Persona> parties) { super(parties); }
    protected Motivation(String xmlDefinition) { super(xmlDefinition); }

    public Instruction instruction() { return instruction; }
    public void setInstruction(Instruction instruction) { this.instruction = instruction; }

    public abstract Process triggers();
}
