// nanoServices core (rev3) — Schedule
// Generated 2025-08-15T06:08:36.564566

package dev.nanoservices;

public abstract class Schedule extends Policy {
    private Policy policy;
    protected Schedule() { super(); }
    protected Schedule(Policy policy) { super(); this.policy = policy; }
    protected Schedule(String xmlDefinition) { super(xmlDefinition); }
    public Policy policy() { return policy; }
    public void setPolicy(Policy policy) { this.policy = policy; }
}
