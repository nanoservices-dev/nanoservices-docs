// nanoServices core (rev3) — Perspective
// Generated 2025-08-15T06:08:36.564566

package dev.nanoservices;

public abstract class Perspective extends Projection {
    private Projection projection;
    protected Perspective() { super(); }
    protected Perspective(Projection projection) { super(); this.projection = projection; }
    protected Perspective(String xmlDefinition) { super(xmlDefinition); }
    public Projection projection() { return projection; }
    public void setProjection(Projection projection) { this.projection = projection; }
}
