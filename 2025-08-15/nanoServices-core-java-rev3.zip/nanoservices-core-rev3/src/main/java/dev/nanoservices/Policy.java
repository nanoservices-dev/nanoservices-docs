// nanoServices core (rev3) — Policy
// Generated 2025-08-15T06:08:36.564566

package dev.nanoservices;

public abstract class Policy extends Perspective {
    private Perspective perspective;
    protected Policy() { super(); }
    protected Policy(Perspective perspective) { super(); this.perspective = perspective; }
    protected Policy(String xmlDefinition) { super(xmlDefinition); }
    public Perspective perspective() { return perspective; }
    public void setPerspective(Perspective perspective) { this.perspective = perspective; }
}
