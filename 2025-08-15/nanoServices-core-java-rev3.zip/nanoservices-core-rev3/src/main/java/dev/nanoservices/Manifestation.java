// nanoServices core (rev3) — Manifestation
// Generated 2025-08-15T06:08:36.564566

package dev.nanoservices;

import java.time.Instant;

public abstract class Manifestation extends World {
    private Instant time;
    private Persona persona;
    private Transformation projects;
    private Projection projection;

    protected Manifestation() { super(); }
    protected Manifestation(Instant time, Persona persona) { super(); this.time = time; this.persona = persona; }
    protected Manifestation(String xmlDefinition) { super(xmlDefinition); }

    public Instant time() { return time; }
    public void setTime(Instant time) { this.time = time; }
    public Persona persona() { return persona; }
    public void setPersona(Persona persona) { this.persona = persona; }
    public Transformation projects() { return projects; }
    public void setProjects(Transformation projects) { this.projects = projects; }
    public Projection projection() { return projection; }
    public void setProjection(Projection projection) { this.projection = projection; }
}
