// nanoServices core (rev3) — Entity
// Generated 2025-08-15T06:08:36.564566

package dev.nanoservices;

public abstract class Entity {
    private String version;
    private String xmlDefinition;

    protected Entity() { }
    protected Entity(String version) { this.version = version; }
    protected Entity(String version, String xmlDefinition) { this.version = version; this.xmlDefinition = xmlDefinition; }
    protected Entity(String xmlDefinition) { this.xmlDefinition = xmlDefinition; }

    public String version() { return version; }
    public void setVersion(String version) { this.version = version; }

    public String xmlDefinition() { return xmlDefinition; }
    public void setXmlDefinition(String xmlDefinition) { this.xmlDefinition = xmlDefinition; }
}
