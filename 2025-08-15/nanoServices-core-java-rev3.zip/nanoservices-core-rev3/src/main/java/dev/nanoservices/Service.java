// nanoServices core (rev3) — Service
// Generated 2025-08-15T06:08:36.564566

package dev.nanoservices;

public abstract class Service extends System {
    private Schedule schedule;
    private Plan fulfills;

    protected Service() { super(); }
    protected Service(java.util.List<Manifestation> elements) { super(elements); }
    protected Service(String xmlDefinition) { super(xmlDefinition); }

    public Schedule schedule() { return schedule; }
    public void setSchedule(Schedule schedule) { this.schedule = schedule; }
    public Plan fulfillsField() { return fulfills; }
    public void setFulfillsField(Plan fulfills) { this.fulfills = fulfills; }

    public abstract Plan fulfills();
    public abstract Schedule works();
}
