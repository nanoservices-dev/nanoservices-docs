# nanoServices core — Java abstract model (rev3)
Generated: 2025-08-15T06:08:36.564566
- `resource` now on Persona.
- Minimal constructors are "klassennamig" and focus on new element lists (`System(List<Manifestation>)`, `Contract(List<Persona>)`) or intrinsic fields.
- Each class has an extra constructor `ClassName(String xmlDefinition)` to attach an XML definition reference/payload.
- Child/pair fields default to null unless provided; no forward references from earlier bridge nodes.