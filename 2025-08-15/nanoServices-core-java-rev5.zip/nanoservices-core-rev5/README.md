# nanoServices core — Java abstract model (rev5)
Generated: 2025-08-15T08:24:30.193760

- Regular getters/setters everywhere (Bean style).
- Encapsulation via Policy/Schedule/Message/Instruction, with delegated accessors
  (e.g., System.getContract() delegates through Policy).
- Constructors per class:
  - Empty
  - Attributes-only (own fields)
  - Complete (attributes + children)
- Collections:
  - System.elements (List<Manifestation>)
  - Contract.parties (List<Persona>)
- No-op operations: Port.open(), Perspective.secure().
- No XML constructors/fields.