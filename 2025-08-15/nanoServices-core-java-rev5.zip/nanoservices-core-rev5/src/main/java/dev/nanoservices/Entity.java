// nanoServices core (rev5) — Entity
// Generated 2025-08-15T08:24:30.193760

package dev.nanoservices;

public abstract class Entity {
    private String version;

    protected Entity() { }
    protected Entity(String version) { this.version = version; }
    protected Entity(Entity entity) { if (entity != null) this.version = entity.version(); }

    public String version() { return version; }
    public void setVersion(String version) { this.version = version; }
}
