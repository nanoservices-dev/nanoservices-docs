// nanoServices core (rev5) — Plan
// Generated 2025-08-15T08:24:30.193760

package dev.nanoservices;

import java.util.List;

public abstract class Plan extends Contract {
    private Schedule schedule;

    protected Plan() { super(); }
    protected Plan(List<Persona> parties) { super(parties); }
    protected Plan(List<Persona> parties, Policy policy, Schedule schedule) { super(parties, policy); this.schedule = schedule; }

    public Schedule getSchedule() { return schedule; }
    public void setSchedule(Schedule schedule) { this.schedule = schedule; }

    public Service getService() { return (schedule != null) ? schedule.getService() : null; }
    public void setService(Service s) { if (schedule != null) schedule.setService(s); }
}
