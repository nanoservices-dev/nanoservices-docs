// nanoServices core (rev5) — Projection
// Generated 2025-08-15T08:24:30.193760

package dev.nanoservices;

public abstract class Projection extends Persona {
    private String contentType;
    private String scope;
    private Persona persona;

    protected Projection() { super(); }
    protected Projection(String contentType, String scope) {
        super(); this.contentType = contentType; this.scope = scope;
    }
    protected Projection(String contentType, String scope, Persona persona) {
        this(contentType, scope); this.persona = persona;
    }

    public String contentType() { return contentType; }
    public void setContentType(String contentType) { this.contentType = contentType; }
    public String scope() { return scope; }
    public void setScope(String scope) { this.scope = scope; }
    public Persona persona() { return persona; }
    public void setPersona(Persona persona) { this.persona = persona; }
}
