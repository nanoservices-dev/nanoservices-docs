// nanoServices core (rev5) — Message
// Generated 2025-08-15T08:24:30.193760

package dev.nanoservices;

public abstract class Message extends Schedule {
    private NanoService nanoService;
    private Task task;

    protected Message() { super(); }
    protected Message(NanoService nanoService, Task task) { this.nanoService = nanoService; this.task = task; }

    public NanoService getNanoService() { return nanoService; }
    public void setNanoService(NanoService nanoService) { this.nanoService = nanoService; }
    public Task getTask() { return task; }
    public void setTask(Task task) { this.task = task; }

    public abstract Message process(Message input);
}
