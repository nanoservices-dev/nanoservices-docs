// nanoServices core (rev5) — Perspective
// Generated 2025-08-15T08:24:30.193760

package dev.nanoservices;

public abstract class Perspective extends Projection {
    private Projection projection;

    protected Perspective() { super(); }
    protected Perspective(Projection projection) { this.projection = projection; }

    public Projection projection() { return projection; }
    public void setProjection(Projection projection) { this.projection = projection; }

    public void secure() { /* no-op */ }
}
