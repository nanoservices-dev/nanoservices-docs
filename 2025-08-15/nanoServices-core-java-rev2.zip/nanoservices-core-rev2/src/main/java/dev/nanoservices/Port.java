// nanoServices core (rev2) — Port
// Generated 2025-08-15T05:27:46.199002

package dev.nanoservices;

public abstract class Port extends Manifestation {
    private String uid;
    private View allows;
    private Perspective opens;

    protected Port() { super(); }

    protected Port(String version, String status, java.time.Instant time, String resource,
                   Persona persona, Transformation projects, Projection projectionHint,
                   String uid, View allows, Perspective opens) {
        super(version, status, time, resource, persona, projects, projectionHint);
        this.uid = uid; this.allows = allows; this.opens = opens;
    }

    public String uid() { return uid; }
    public void setUid(String uid) { this.uid = uid; }
    public View allows() { return allows; }
    public void setAllows(View allows) { this.allows = allows; }
    public Perspective opens() { return opens; }
    public void setOpens(Perspective opens) { this.opens = opens; }
}
