// nanoServices core (rev2) — Transformation
// Generated 2025-08-15T05:27:46.199002

package dev.nanoservices;

public abstract class Transformation extends Idea {
    private String purpose;
    private Double entropy;
    private Manifestation assumes;   // world partner (optional)
    private Projection instantiates; // bridge partner

    protected Transformation() { super(); }

    protected Transformation(String version, String type, Double priority,
                             String purpose, Double entropy,
                             Manifestation assumes, Projection instantiates) {
        super(version, type, priority);
        this.purpose = purpose; this.entropy = entropy;
        this.assumes = assumes; this.instantiates = instantiates;
    }

    public String purpose() { return purpose; }
    public void setPurpose(String purpose) { this.purpose = purpose; }
    public Double entropy() { return entropy; }
    public void setEntropy(Double entropy) { this.entropy = entropy; }
    public Manifestation assumes() { return assumes; }
    public void setAssumes(Manifestation assumes) { this.assumes = assumes; }
    public Projection instantiates() { return instantiates; }
    public void setInstantiates(Projection instantiates) { this.instantiates = instantiates; }
}
