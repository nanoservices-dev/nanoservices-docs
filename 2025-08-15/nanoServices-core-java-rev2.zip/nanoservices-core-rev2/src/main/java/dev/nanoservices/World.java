// nanoServices core (rev2) — World
// Generated 2025-08-15T05:27:46.199002

package dev.nanoservices;

public abstract class World extends Entity {
    private String status;
    protected World() { super(); }
    protected World(String version, String status) { super(version); this.status = status; }
    public String status() { return status; }
    public void setStatus(String status) { this.status = status; }
}
