// nanoServices core (rev2) — Manifestation
// Generated 2025-08-15T05:27:46.199002

package dev.nanoservices;

import java.time.Instant;

public abstract class Manifestation extends World {
    private Instant time;
    private String resource;
    private Persona persona;              // pair ref
    private Transformation projects;      // idea ref
    private Projection projectionHint;    // bridge ref

    protected Manifestation() { super(); }

    protected Manifestation(String version, String status,
                            Instant time, String resource,
                            Persona persona,
                            Transformation projects,
                            Projection projectionHint) {
        super(version, status);
        this.time = time; this.resource = resource;
        this.persona = persona; this.projects = projects; this.projectionHint = projectionHint;
    }

    public Instant time() { return time; }
    public void setTime(Instant time) { this.time = time; }
    public String resource() { return resource; }
    public void setResource(String resource) { this.resource = resource; }
    public Persona persona() { return persona; }
    public void setPersona(Persona persona) { this.persona = persona; }
    public Transformation projects() { return projects; }
    public void setProjects(Transformation projects) { this.projects = projects; }
    public Projection projectionHint() { return projectionHint; }
    public void setProjectionHint(Projection projectionHint) { this.projectionHint = projectionHint; }
}
