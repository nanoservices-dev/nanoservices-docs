// nanoServices core (rev2) — Contract
// Generated 2025-08-15T05:27:46.199002

package dev.nanoservices;

public abstract class Contract extends View {
    private System restricts;
    private Policy justifies;

    protected Contract() { super(); }

    protected Contract(String version, String type, Double priority,
                       String purpose, Double entropy,
                       Manifestation assumes, Projection instantiates,
                       String language, String location, String checksum,
                       Port requires, Perspective concretizes,
                       System restricts, Policy justifies) {
        super(version, type, priority, purpose, entropy, assumes, instantiates, language, location, checksum, requires, concretizes);
        this.restricts = restricts; this.justifies = justifies;
    }

    public System restricts() { return restricts; }
    public void setRestricts(System restricts) { this.restricts = restricts; }
    public Policy justifies() { return justifies; }
    public void setJustifies(Policy justifies) { this.justifies = justifies; }
}
