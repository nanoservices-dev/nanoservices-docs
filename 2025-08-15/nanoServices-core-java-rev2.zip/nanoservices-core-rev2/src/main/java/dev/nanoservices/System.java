// nanoServices core (rev2) — System
// Generated 2025-08-15T05:27:46.199002

package dev.nanoservices;

public abstract class System extends Port {
    private Contract serves;
    private Policy respects;

    protected System() { super(); }

    protected System(String version, String status, java.time.Instant time, String resource,
                     Persona persona, Transformation projects, Projection projectionHint,
                     String uid, View allows, Perspective opens,
                     Contract serves, Policy respects) {
        super(version, status, time, resource, persona, projects, projectionHint, uid, allows, opens);
        this.serves = serves; this.respects = respects;
    }

    public Contract serves() { return serves; }
    public void setServes(Contract serves) { this.serves = serves; }
    public Policy respects() { return respects; }
    public void setRespects(Policy respects) { this.respects = respects; }
}
