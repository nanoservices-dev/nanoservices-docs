// nanoServices core (rev2) — View
// Generated 2025-08-15T05:27:46.199002

package dev.nanoservices;

public abstract class View extends Transformation {
    private String language;
    private String location;
    private String checksum;
    private Port requires;
    private Perspective concretizes;

    protected View() { super(); }

    protected View(String version, String type, Double priority,
                   String purpose, Double entropy,
                   Manifestation assumes, Projection instantiates,
                   String language, String location, String checksum,
                   Port requires, Perspective concretizes) {
        super(version, type, priority, purpose, entropy, assumes, instantiates);
        this.language = language; this.location = location; this.checksum = checksum;
        this.requires = requires; this.concretizes = concretizes;
    }

    public String language() { return language; }
    public void setLanguage(String language) { this.language = language; }
    public String location() { return location; }
    public void setLocation(String location) { this.location = location; }
    public String checksum() { return checksum; }
    public void setChecksum(String checksum) { this.checksum = checksum; }
    public Port requires() { return requires; }
    public void setRequires(Port requires) { this.requires = requires; }
    public Perspective concretizes() { return concretizes; }
    public void setConcretizes(Perspective concretizes) { this.concretizes = concretizes; }
}
