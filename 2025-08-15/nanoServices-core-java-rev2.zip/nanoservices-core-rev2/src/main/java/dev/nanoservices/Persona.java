// nanoServices core (rev2) — Persona
// Generated 2025-08-15T05:27:46.199002

package dev.nanoservices;

public abstract class Persona extends Entity {
    private Idea idea;
    private World world;
    protected Persona() { super(); }
    protected Persona(String version, Idea idea, World world) {
        super(version); this.idea = idea; this.world = world;
    }
    public Idea idea() { return idea; }
    public void setIdea(Idea idea) { this.idea = idea; }
    public World world() { return world; }
    public void setWorld(World world) { this.world = world; }
}
