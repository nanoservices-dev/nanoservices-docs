// nanoServices core (rev2) — Task
// Generated 2025-08-15T05:27:46.199002

package dev.nanoservices;

public abstract class Task extends Plan {
    private NanoService defines;
    private Message reports;

    protected Task() { super(); }

    protected Task(String version, String type, Double priority,
                   String purpose, Double entropy,
                   Manifestation assumes, Projection instantiates,
                   String language, String location, String checksum,
                   Port requires, Perspective concretizes,
                   System restricts, Policy justifies,
                   Service describes, Schedule schemes,
                   NanoService defines, Message reports) {
        super(version, type, priority, purpose, entropy, assumes, instantiates, language, location, checksum, requires, concretizes, restricts, justifies, describes, schemes);
        this.defines = defines; this.reports = reports;
    }

    public NanoService defines() { return defines; }
    public void setDefines(NanoService defines) { this.defines = defines; }
    public Message reports() { return reports; }
    public void setReports(Message reports) { this.reports = reports; }
}
