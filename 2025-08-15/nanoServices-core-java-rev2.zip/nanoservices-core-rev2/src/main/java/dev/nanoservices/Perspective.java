// nanoServices core (rev2) — Perspective
// Generated 2025-08-15T05:27:46.199002

package dev.nanoservices;

public abstract class Perspective extends Projection {
    protected Perspective() { super(); }
    protected Perspective(String version, Idea idea, World world, String contentType, String scope) {
        super(version, idea, world, contentType, scope);
    }
}
