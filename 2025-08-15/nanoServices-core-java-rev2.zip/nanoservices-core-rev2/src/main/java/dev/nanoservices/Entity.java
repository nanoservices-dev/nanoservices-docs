// nanoServices core (rev2) — Entity
// Generated 2025-08-15T05:27:46.199002

package dev.nanoservices;

public abstract class Entity {
    private String version;
    protected Entity() { }
    protected Entity(String version) { this.version = version; }
    public String version() { return version; }
    public void setVersion(String version) { this.version = version; }
}
