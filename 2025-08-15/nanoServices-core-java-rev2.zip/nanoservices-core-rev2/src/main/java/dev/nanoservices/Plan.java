// nanoServices core (rev2) — Plan
// Generated 2025-08-15T05:27:46.199002

package dev.nanoservices;

public abstract class Plan extends Contract {
    private Service describes;
    private Schedule schemes;

    protected Plan() { super(); }

    protected Plan(String version, String type, Double priority,
                   String purpose, Double entropy,
                   Manifestation assumes, Projection instantiates,
                   String language, String location, String checksum,
                   Port requires, Perspective concretizes,
                   System restricts, Policy justifies,
                   Service describes, Schedule schemes) {
        super(version, type, priority, purpose, entropy, assumes, instantiates, language, location, checksum, requires, concretizes, restricts, justifies);
        this.describes = describes; this.schemes = schemes;
    }

    public Service describes() { return describes; }
    public void setDescribes(Service describes) { this.describes = describes; }
    public Schedule schemes() { return schemes; }
    public void setSchemes(Schedule schemes) { this.schemes = schemes; }
}
