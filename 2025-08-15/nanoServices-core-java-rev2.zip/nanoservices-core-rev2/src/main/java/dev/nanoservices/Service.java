// nanoServices core (rev2) — Service
// Generated 2025-08-15T05:27:46.199002

package dev.nanoservices;

public abstract class Service extends System {
    private Plan fulfills;
    private Schedule works;

    protected Service() { super(); }

    protected Service(String version, String status, java.time.Instant time, String resource,
                      Persona persona, Transformation projects, Projection projectionHint,
                      String uid, View allows, Perspective opens,
                      Contract serves, Policy respects,
                      Plan fulfills, Schedule works) {
        super(version, status, time, resource, persona, projects, projectionHint, uid, allows, opens, serves, respects);
        this.fulfills = fulfills; this.works = works;
    }

    public Plan fulfills() { return fulfills; }
    public void setFulfills(Plan fulfills) { this.fulfills = fulfills; }
    public Schedule works() { return works; }
    public void setWorks(Schedule works) { this.works = works; }
}
