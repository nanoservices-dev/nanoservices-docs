// nanoServices core (rev2) — Idea
// Generated 2025-08-15T05:27:46.199002

package dev.nanoservices;

public abstract class Idea extends Entity {
    private String type;
    private Double priority;
    protected Idea() { super(); }
    protected Idea(String version, String type, Double priority) {
        super(version); this.type = type; this.priority = priority;
    }
    public String type() { return type; }
    public void setType(String type) { this.type = type; }
    public Double priority() { return priority; }
    public void setPriority(Double priority) { this.priority = priority; }
}
