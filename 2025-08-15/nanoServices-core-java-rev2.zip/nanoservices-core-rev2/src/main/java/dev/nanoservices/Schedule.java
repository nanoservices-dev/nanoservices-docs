// nanoServices core (rev2) — Schedule
// Generated 2025-08-15T05:27:46.199002

package dev.nanoservices;

public abstract class Schedule extends Policy {
    protected Schedule() { super(); }
    protected Schedule(String version, Idea idea, World world, String contentType, String scope) {
        super(version, idea, world, contentType, scope);
    }
}
