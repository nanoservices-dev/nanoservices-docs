// nanoServices core (rev2) — Projection
// Generated 2025-08-15T05:27:46.199002

package dev.nanoservices;

public abstract class Projection extends Persona {
    private String contentType;
    private String scope;
    protected Projection() { super(); }
    protected Projection(String version, Idea idea, World world, String contentType, String scope) {
        super(version, idea, world); this.contentType = contentType; this.scope = scope;
    }
    public String contentType() { return contentType; }
    public void setContentType(String contentType) { this.contentType = contentType; }
    public String scope() { return scope; }
    public void setScope(String scope) { this.scope = scope; }
}
