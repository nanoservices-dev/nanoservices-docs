# nanoServices core — Java abstract model (rev2)
Generated: 2025-08-15T05:27:46.199002
- All classes abstract, package `dev.nanoservices`.
- Bridge classes do not hold forward references to World/Idea descendants.
- Persona holds only Idea + World roots (union by composition).
- World/Idea nodes hold pair references back to Bridge and across lines where needed.
- `Message` has `public abstract Message process(Message input)`.