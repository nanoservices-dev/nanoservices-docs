# nanoServices core — Java abstract model (rev5.4)
Generated: 2025-08-15T09:12:22.828289

Scope:
- **Finalized bridge rule**: Only *bridge* classes hold both ends.
  - Projection ↔ holds (Manifestation, Transformation)
  - Policy ↔ holds (System, Contract)
  - Schedule ↔ holds (Service, Plan)
  - Message ↔ holds (NanoService, Task)
  - Instruction ↔ holds (Process, Motivation)
- **Endpoints** do not reference their counterpart or the bridge:
  - Manifestation: only `time`, `persona` (no Transformation, no Projection).
  - Transformation: now only `purpose`, `entropy` (no Manifestation, no Projection).
- All other classes identical to rev5.2 (encapsulation + bean getters/setters, Port.open(), Perspective.secure()).

Notes:
- `View` still references `Port` (`requires`) as a cross-layer link per TTL semantics.
- `Port` still references `Projection` as the world completion to the bridge.