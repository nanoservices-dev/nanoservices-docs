// nanoServices core (rev5.4) — Projection
// Generated 2025-08-15T09:12:22.828289


package dev.nanoservices;

public abstract class Projection extends Persona {
    private String contentType;
    private String scope;

    // Bridge ends only
    private Manifestation manifestation;   // World anchor
    private Transformation transformation; // Idea anchor

    protected Projection() { super(); }
    // attributes-only
    protected Projection(String contentType, String scope) {
        super();
        this.contentType = contentType;
        this.scope = scope;
    }
    // complete (attributes + bridge ends)
    protected Projection(String contentType, String scope,
                         Manifestation manifestation,
                         Transformation transformation) {
        this(contentType, scope);
        this.manifestation = manifestation;
        this.transformation = transformation;
    }

    public String contentType() { return contentType; }
    public void setContentType(String contentType) { this.contentType = contentType; }

    public String scope() { return scope; }
    public void setScope(String scope) { this.scope = scope; }

    public Manifestation manifestation() { return manifestation; }
    public void setManifestation(Manifestation manifestation) { this.manifestation = manifestation; }

    public Transformation transformation() { return transformation; }
    public void setTransformation(Transformation transformation) { this.transformation = transformation; }
}
