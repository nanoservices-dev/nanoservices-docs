// nanoServices core (rev5.4) — World
// Generated 2025-08-15T09:12:22.828289



package dev.nanoservices;

public abstract class World extends Entity {
    private String status;

    protected World() { super(); }
    protected World(String status) { super(); this.status = status; }
    protected World(String status, Entity entity) { super(entity); this.status = status; }

    public String status() { return status; }
    public void setStatus(String status) { this.status = status; }
}
