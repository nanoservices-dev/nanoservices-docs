// nanoServices core (rev5.4) — Entity
// Generated 2025-08-15T09:12:22.828289



package dev.nanoservices;

public abstract class Entity {
    private String version;

    protected Entity() { }
    protected Entity(String version) { this.version = version; }
    protected Entity(Entity entity) { if (entity != null) this.version = entity.version(); }

    public String version() { return version; }
    public void setVersion(String version) { this.version = version; }
}
