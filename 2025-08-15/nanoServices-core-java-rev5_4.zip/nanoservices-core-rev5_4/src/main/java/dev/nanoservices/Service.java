// nanoServices core (rev5.4) — Service
// Generated 2025-08-15T09:12:22.828289



package dev.nanoservices;

import java.util.List;

public abstract class Service extends System {
    private Schedule schedule;

    protected Service() { super(); }
    protected Service(List<Manifestation> elements) { super(elements); }
    protected Service(List<Manifestation> elements, Schedule schedule) { super(elements); this.schedule = schedule; }

    public Schedule getSchedule() { return schedule; }
    public void setSchedule(Schedule schedule) { this.schedule = schedule; }

    public Plan getPlan() { return (schedule != null) ? schedule.getPlan() : null; }
    public void setPlan(Plan p) { if (schedule != null) { schedule.setPlan(p); if (p != null) p.setSchedule(schedule); } }
}
