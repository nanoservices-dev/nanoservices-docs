// nanoServices core (rev5.4) — Policy
// Generated 2025-08-15T09:12:22.828289



package dev.nanoservices;

public abstract class Policy extends Perspective {
    private System system;
    private Contract contract;

    protected Policy() { super(); }
    protected Policy(System system, Contract contract) {
        this.system = system; this.contract = contract;
    }

    public System getSystem() { return system; }
    public void setSystem(System system) { this.system = system; }

    public Contract getContract() { return contract; }
    public void setContract(Contract contract) { this.contract = contract; }
}
