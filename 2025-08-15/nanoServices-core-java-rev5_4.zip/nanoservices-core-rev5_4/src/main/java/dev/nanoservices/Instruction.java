// nanoServices core (rev5.4) — Instruction
// Generated 2025-08-15T09:12:22.828289



package dev.nanoservices;

public abstract class Instruction extends Message {
    private Process process;
    private Motivation motivation;

    protected Instruction() { super(); }
    protected Instruction(Process process, Motivation motivation) {
        this.process = process; this.motivation = motivation;
    }

    public Process getProcess() { return process; }
    public void setProcess(Process process) { this.process = process; }

    public Motivation getMotivation() { return motivation; }
    public void setMotivation(Motivation motivation) { this.motivation = motivation; }
}
