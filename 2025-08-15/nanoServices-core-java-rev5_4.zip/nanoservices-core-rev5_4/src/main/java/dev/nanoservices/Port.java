// nanoServices core (rev5.4) — Port
// Generated 2025-08-15T09:12:22.828289



package dev.nanoservices;

public abstract class Port extends Manifestation {
    private String uid;
    private Projection projection;
    private Perspective opens;
    private View allows;

    protected Port() { super(); }
    protected Port(String uid, Projection projection) { super(); this.uid = uid; this.projection = projection; }
    protected Port(String uid, Projection projection, Perspective opens, View allows) {
        this(uid, projection); this.opens = opens; this.allows = allows;
    }

    public String uid() { return uid; }
    public void setUid(String uid) { this.uid = uid; }

    public Projection projection() { return projection; }
    public void setProjection(Projection projection) { this.projection = projection; }

    public Perspective opens() { return opens; }
    public void setOpens(Perspective opens) { this.opens = opens; }

    public View allows() { return allows; }
    public void setAllows(View allows) { this.allows = allows; }

    public void open() { /* no-op */ }
}
