// nanoServices core (rev5.4) — NanoService
// Generated 2025-08-15T09:12:22.828289



package dev.nanoservices;

import java.util.List;

public abstract class NanoService extends Service {
    private Message message;

    protected NanoService() { super(); }
    protected NanoService(List<Manifestation> elements) { super(elements); }
    protected NanoService(List<Manifestation> elements, Message message) { super(elements); this.message = message; }

    public Message getMessage() { return message; }
    public void setMessage(Message message) { this.message = message; }

    public Task getTask() { return (message != null) ? message.getTask() : null; }
    public void setTask(Task t) { if (message != null) { message.setTask(t); if (t != null) t.setMessage(message); } }
}
