// nanoServices core (rev5.4) — Persona
// Generated 2025-08-15T09:12:22.828289



package dev.nanoservices;

public abstract class Persona extends Entity {
    private String resource;
    private Idea idea;
    private World world;

    protected Persona() { super(); }
    protected Persona(String resource) { this.resource = resource; }
    protected Persona(String resource, Idea idea, World world) {
        this.resource = resource; this.idea = idea; this.world = world;
    }
    protected Persona(String resource, Entity entity, Idea idea, World world) {
        super(entity); this.resource = resource; this.idea = idea; this.world = world;
    }

    public String resource() { return resource; }
    public void setResource(String resource) { this.resource = resource; }

    public Idea idea() { return idea; }
    public void setIdea(Idea idea) { this.idea = idea; }

    public World world() { return world; }
    public void setWorld(World world) { this.world = world; }
}
