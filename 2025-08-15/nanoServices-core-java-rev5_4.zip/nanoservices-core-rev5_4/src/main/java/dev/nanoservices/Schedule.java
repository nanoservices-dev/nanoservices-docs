// nanoServices core (rev5.4) — Schedule
// Generated 2025-08-15T09:12:22.828289



package dev.nanoservices;

public abstract class Schedule extends Policy {
    private Service service;
    private Plan plan;

    protected Schedule() { super(); }
    protected Schedule(Service service, Plan plan) { this.service = service; this.plan = plan; }

    public Service getService() { return service; }
    public void setService(Service service) { this.service = service; }

    public Plan getPlan() { return plan; }
    public void setPlan(Plan plan) { this.plan = plan; }
}
