// nanoServices core (rev5.4) — System
// Generated 2025-08-15T09:12:22.828289



package dev.nanoservices;

import java.util.ArrayList;
import java.util.List;

public abstract class System extends Port {
    private final List<Manifestation> elements = new ArrayList<>();
    private Policy policy;

    protected System() { super(); }
    protected System(List<Manifestation> elements) { super(); if (elements != null) this.elements.addAll(elements); }
    protected System(List<Manifestation> elements, Policy policy) { this(elements); this.policy = policy; }

    public List<Manifestation> getElements() { return elements; }
    public void setElements(List<Manifestation> elements) { this.elements.clear(); if (elements != null) this.elements.addAll(elements); }

    public Policy getPolicy() { return policy; }
    public void setPolicy(Policy policy) { this.policy = policy; }

    public Contract getContract() { return (policy != null) ? policy.getContract() : null; }
    public void setContract(Contract c) {
        if (policy != null) {
            policy.setContract(c);
            if (c != null) {
                c.setPolicy(policy);
                c.setSystem(this);
            }
        }
    }
}
