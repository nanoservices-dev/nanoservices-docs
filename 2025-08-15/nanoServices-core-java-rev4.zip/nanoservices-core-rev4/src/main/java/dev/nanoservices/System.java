// nanoServices core (rev4) — System
// Generated 2025-08-15T07:03:37.539676

package dev.nanoservices;

import java.util.ArrayList;
import java.util.List;

public abstract class System extends Port {
    private final List<Manifestation> elements = new ArrayList<>();
    private Policy policy;

    protected System(List<Manifestation> elements) {
        super();
        if (elements != null) this.elements.addAll(elements);
    }
    protected System(String xmlDefinition) { super(xmlDefinition, true); }

    public List<Manifestation> elements() { return elements; }
    public System addElement(Manifestation m) { if (m != null) elements.add(m); return this; }

    public Policy  respects() { return policy; }
    public System  respect(Policy p) { this.policy = p; return this; }

    public Contract serves() { return (policy != null) ? policy.mirrors() : null; }

    public System serve(Contract c) {
        if (policy != null && c != null) {
            policy.restrict(c);
            policy.mirror(c);
        }
        return this;
    }
}
