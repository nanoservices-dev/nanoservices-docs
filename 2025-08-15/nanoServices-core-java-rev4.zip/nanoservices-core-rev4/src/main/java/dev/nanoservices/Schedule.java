// nanoServices core (rev4) — Schedule
// Generated 2025-08-15T07:03:37.539676

package dev.nanoservices;

public abstract class Schedule extends Policy {
    private Service service;
    private Plan plan;

    protected Schedule() { super(); }
    protected Schedule(String xmlDefinition) { super(xmlDefinition, true); }

    public Service registers() { return service; }
    public Plan    separates() { return plan;   }

    public Schedule register(Service s) { this.service = s; return this; }
    public Schedule separate(Plan p)    { this.plan = p;   return this; }
}
