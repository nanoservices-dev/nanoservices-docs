// nanoServices core (rev4) — Process
// Generated 2025-08-15T07:03:37.539676

package dev.nanoservices;

import java.util.List;

public abstract class Process extends NanoService {
    private String pid;
    private Instruction instruction;

    protected Process(List<Manifestation> elements) { super(elements); }
    protected Process(String pid, Instruction instruction) { super(java.util.Collections.emptyList()); this.pid = pid; this.instruction = instruction; }
    protected Process(String xmlDefinition) { super(xmlDefinition, true); }

    public String pid() { return pid; }
    public Process pid(String pid) { this.pid = pid; return this; }

    public Instruction runs() { return instruction; }
    public Process run(Instruction i) { this.instruction = i; return this; }

    public Motivation targets() { return (instruction != null) ? instruction.motivation() : null; }

    public Process target(Motivation m) {
        if (instruction != null && m != null) instruction.engage(m);
        return this;
    }
}
