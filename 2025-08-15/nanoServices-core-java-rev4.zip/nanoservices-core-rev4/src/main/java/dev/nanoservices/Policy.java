// nanoServices core (rev4) — Policy
// Generated 2025-08-15T07:03:37.539676

package dev.nanoservices;

public abstract class Policy extends Perspective {
    private System system;
    private Contract contract;

    protected Policy() { super(); }
    protected Policy(String xmlDefinition) { super(xmlDefinition, true); }

    public System rules()   { return system; }
    public Contract mirrors() { return contract; }

    public Policy rule(System s)   { this.system = s; return this; }
    public Policy mirror(Contract c) { this.contract = c; return this; }

    public Policy restrict(Contract c) {
        if (c != null) {
            if (this.system != null) c.restrict(this.system);
            c.justify(this);
            this.contract = c;
        }
        return this;
    }
}
