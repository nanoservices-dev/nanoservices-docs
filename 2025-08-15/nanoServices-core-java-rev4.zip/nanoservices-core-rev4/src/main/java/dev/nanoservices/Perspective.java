// nanoServices core (rev4) — Perspective
// Generated 2025-08-15T07:03:37.539676

package dev.nanoservices;

public abstract class Perspective extends Projection {
    private Projection projection;

    protected Perspective() { super(); }
    protected Perspective(Projection projection) { super(); this.projection = projection; }
    protected Perspective(String xmlDefinition) { super(xmlDefinition, true); }

    public Projection projection() { return projection; }
    public void setProjection(Projection projection) { this.projection = projection; }
}
