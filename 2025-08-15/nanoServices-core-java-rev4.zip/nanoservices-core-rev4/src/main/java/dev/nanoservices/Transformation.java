// nanoServices core (rev4) — Transformation
// Generated 2025-08-15T07:03:37.539676

package dev.nanoservices;

public abstract class Transformation extends Idea {
    private String purpose;
    private Double entropy;
    private Projection projection;
    private Manifestation assumes;

    protected Transformation() { super(); }
    protected Transformation(String purpose, Double entropy, Projection projection) { super(); this.purpose = purpose; this.entropy = entropy; this.projection = projection; }
    protected Transformation(String xmlDefinition) { super(xmlDefinition, true); }

    public String purpose() { return purpose; }
    public void setPurpose(String purpose) { this.purpose = purpose; }
    public Double entropy() { return entropy; }
    public void setEntropy(Double entropy) { this.entropy = entropy; }
    public Projection projection() { return projection; }
    public void setProjection(Projection projection) { this.projection = projection; }
    public Manifestation assumes() { return assumes; }
    public void setAssumes(Manifestation assumes) { this.assumes = assumes; }
}
