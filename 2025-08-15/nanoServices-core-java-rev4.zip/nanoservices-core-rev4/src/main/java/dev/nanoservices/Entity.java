// nanoServices core (rev4) — Entity
// Generated 2025-08-15T07:03:37.539676

package dev.nanoservices;

public abstract class Entity {
    private String version;
    private String xmlDefinition;

    protected Entity() { }
    protected Entity(String version) { this.version = version; }
    protected Entity(String xmlDefinition, boolean xmlOnly) { this.xmlDefinition = xmlDefinition; }
    protected Entity(String version, String xmlDefinition) { this.version = version; this.xmlDefinition = xmlDefinition; }

    public String version() { return version; }
    public void setVersion(String version) { this.version = version; }

    public String xmlDefinition() { return xmlDefinition; }
    public void setXmlDefinition(String xmlDefinition) { this.xmlDefinition = xmlDefinition; }
}
