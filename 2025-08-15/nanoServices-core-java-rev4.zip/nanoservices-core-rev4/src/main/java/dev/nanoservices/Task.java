// nanoServices core (rev4) — Task
// Generated 2025-08-15T07:03:37.539676

package dev.nanoservices;

import java.util.List;

public abstract class Task extends Plan {
    private Message message;

    protected Task(List<Persona> parties) { super(parties); }
    protected Task(String xmlDefinition) { super(xmlDefinition, true); }

    public Message reports() { return message; }
    public Task report(Message m) { this.message = m; return this; }

    public NanoService defines() { return (message != null) ? message.belongsTo() : null; }

    public Task define(NanoService s) {
        if (message != null && s != null) message.belongTo(s);
        return this;
    }
}
