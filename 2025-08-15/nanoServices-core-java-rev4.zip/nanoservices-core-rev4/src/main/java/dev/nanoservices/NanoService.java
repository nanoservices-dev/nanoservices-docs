// nanoServices core (rev4) — NanoService
// Generated 2025-08-15T07:03:37.539676

package dev.nanoservices;

import java.util.List;

public abstract class NanoService extends Service {
    private Message message;

    protected NanoService(List<Manifestation> elements) { super(elements); }
    protected NanoService(String xmlDefinition) { super(xmlDefinition, true); }

    public Message sends() { return message; }
    public NanoService send(Message m) { this.message = m; return this; }

    public Task executes() { return (message != null) ? message.represents() : null; }

    public NanoService execute(Task t) {
        if (message != null && t != null) {
            message.represent(t);
            message.belongTo(this);
        }
        return this;
    }
}
