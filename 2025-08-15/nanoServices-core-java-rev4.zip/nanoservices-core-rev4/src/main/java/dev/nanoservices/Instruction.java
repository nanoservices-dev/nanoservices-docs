// nanoServices core (rev4) — Instruction
// Generated 2025-08-15T07:03:37.539676

package dev.nanoservices;

public abstract class Instruction extends Message {
    private Process process;
    private Motivation motivation;

    protected Instruction() { super(); }
    protected Instruction(String xmlDefinition) { super(xmlDefinition, true); }

    public Process    needs()     { return process; }
    public Motivation motivation(){ return motivation; }

    public Instruction need(Process p)   { this.process = p;    return this; }
    public Instruction engage(Motivation m) { this.motivation = m; return this; }
}
