// nanoServices core (rev4) — Persona
// Generated 2025-08-15T07:03:37.539676

package dev.nanoservices;

public abstract class Persona extends Entity {
    private String resource;
    private Idea idea;
    private World world;

    protected Persona() { super(); }
    protected Persona(String resource, Idea idea, World world) { super(); this.resource = resource; this.idea = idea; this.world = world; }
    protected Persona(String xmlDefinition) { super(xmlDefinition, true); }

    public String resource() { return resource; }
    public void setResource(String resource) { this.resource = resource; }
    public Idea idea() { return idea; }
    public void setIdea(Idea idea) { this.idea = idea; }
    public World world() { return world; }
    public void setWorld(World world) { this.world = world; }
}
