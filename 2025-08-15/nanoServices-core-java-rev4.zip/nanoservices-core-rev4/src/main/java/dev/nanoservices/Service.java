// nanoServices core (rev4) — Service
// Generated 2025-08-15T07:03:37.539676

package dev.nanoservices;

import java.util.List;

public abstract class Service extends System {
    private Schedule schedule;

    protected Service(List<Manifestation> elements) { super(elements); }
    protected Service(String xmlDefinition) { super(xmlDefinition, true); }

    public Schedule works() { return schedule; }
    public Service  work(Schedule s) { this.schedule = s; return this; }

    public Plan fulfills() { return (schedule != null) ? schedule.separates() : null; }

    public Service fulfill(Plan p) {
        if (schedule != null && p != null) schedule.separate(p);
        return this;
    }
}
