// nanoServices core (rev4) — Contract
// Generated 2025-08-15T07:03:37.539676

package dev.nanoservices;

import java.util.ArrayList;
import java.util.List;

public abstract class Contract extends View {
    private final List<Persona> parties = new ArrayList<>();
    private Policy policy;

    protected Contract(List<Persona> parties) { super(); if (parties != null) this.parties.addAll(parties); }
    protected Contract(String xmlDefinition) { super(xmlDefinition, true); }

    public List<Persona> parties() { return parties; }
    public Contract addParty(Persona p) { if (p != null) parties.add(p); return this; }

    public Policy justifies() { return policy; }
    public Contract justify(Policy p) { this.policy = p; return this; }

    public System restricts() { return (policy != null) ? policy.rules() : null; }

    // Attach via policy from System side; no direct back-attach here unless needed.
}
