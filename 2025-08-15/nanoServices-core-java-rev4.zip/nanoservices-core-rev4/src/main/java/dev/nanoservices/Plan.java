// nanoServices core (rev4) — Plan
// Generated 2025-08-15T07:03:37.539676

package dev.nanoservices;

import java.util.List;

public abstract class Plan extends Contract {
    private Schedule schedule;

    protected Plan(List<Persona> parties) { super(parties); }
    protected Plan(String xmlDefinition) { super(xmlDefinition, true); }

    public Schedule schemes() { return schedule; }
    public Plan scheme(Schedule s) { this.schedule = s; return this; }

    public Service describes() { return (schedule != null) ? schedule.registers() : null; }

    public Plan describe(Service s) {
        if (schedule != null && s != null) schedule.register(s);
        return this;
    }
}
