// nanoServices core (rev4) — Message
// Generated 2025-08-15T07:03:37.539676

package dev.nanoservices;

public abstract class Message extends Schedule {
    private NanoService nanoService;
    private Task task;

    protected Message() { super(); }
    protected Message(String xmlDefinition) { super(xmlDefinition, true); }

    public NanoService belongsTo() { return nanoService; }
    public Task        represents() { return task; }

    public Message belongTo(NanoService s) { this.nanoService = s; return this; }
    public Message represent(Task t)       { this.task = t;        return this; }

    public abstract Message process(Message input);
}
