// nanoServices core (rev4) — Motivation
// Generated 2025-08-15T07:03:37.539676

package dev.nanoservices;

import java.util.List;

public abstract class Motivation extends Task {
    private Instruction instruction;

    protected Motivation(List<Persona> parties) { super(parties); }
    protected Motivation(String xmlDefinition) { super(xmlDefinition, true); }

    public Instruction instruction() { return instruction; }
    public Motivation instruction(Instruction i) { this.instruction = i; return this; }

    public Process triggers() { return (instruction != null) ? instruction.needs() : null; }

    public Motivation trigger(Process p) {
        if (instruction != null && p != null) instruction.need(p);
        return this;
    }
}
