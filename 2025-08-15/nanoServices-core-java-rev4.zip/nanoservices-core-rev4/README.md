# nanoServices core — Java abstract model (rev4)
Generated: 2025-08-15T07:03:37.539676

Encapsulation rules implemented:
- System ↔ (Policy) ↔ Contract; System.serves() derived via Policy.mirrors(); System.serve(Contract) delegates to Policy.restrict(c)+mirror(c).
- Service ↔ (Schedule) ↔ Plan;  Service.fulfills() derived via Schedule.separates(); Service.fulfill(Plan) delegates to Schedule.separate(p).
- NanoService ↔ (Message) ↔ Task; NanoService.executes() derived via Message.represents(); NanoService.execute(Task) delegates to Message.represent(t)+belongTo(this).
- Process ↔ (Instruction) ↔ Motivation; Process.targets() derived via Instruction.motivation(); Process.target(Motivation) delegates to Instruction.engage(m).

Constructors:
- Minimal, class-named constructors (e.g., System(List<Manifestation>), Contract(List<Persona>), Manifestation(Instant, Persona), Port(String, Projection), Process(String, Instruction)).
- Plus XML constructor: ClassName(String xmlDefinition), and no-arg for frameworks.

Additional notes:
- Persona owns `resource` and composes Idea + World.
- Earlier bridge nodes do not hold forward references to later world/idea nodes.